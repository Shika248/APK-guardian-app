package com.example.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class InstalledApp(
    val name: String,
    val packageName: String,
    val version: String,
    val installDate: Long,
    val updateDate: Long,
    val icon: Drawable?,
    val installer: String?,
    val isSystemApp: Boolean,
    val requestedPermissions: List<String>,
    val apkSize: Long
)

class AppScanner(private val context: Context) {
    suspend fun getInstalledApps(includeSystem: Boolean = false): List<InstalledApp> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA)
        packages.mapNotNull { pi ->
            val ai = pi.applicationInfo ?: return@mapNotNull null
            val isSystemApp = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            
            if (!includeSystem && isSystemApp) return@mapNotNull null

            val installer = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                try { pm.getInstallSourceInfo(pi.packageName).installingPackageName } catch (e: Exception) { null }
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pi.packageName)
            }
            
            val icon = try { pm.getApplicationIcon(pi.packageName) } catch(e: Exception) { null }
            val label = pm.getApplicationLabel(ai).toString()
            val apkSize = File(ai.sourceDir).length()
            
            InstalledApp(
                name = label,
                packageName = pi.packageName,
                version = pi.versionName ?: "Unknown",
                installDate = pi.firstInstallTime,
                updateDate = pi.lastUpdateTime,
                icon = icon,
                installer = installer,
                isSystemApp = isSystemApp,
                requestedPermissions = pi.requestedPermissions?.toList() ?: emptyList(),
                apkSize = apkSize
            )
        }.sortedBy { it.name.lowercase() }
    }
}
