package com.example.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

data class ApkAnalysisResult(
    val fileName: String,
    val packageName: String,
    val appLabel: String,
    val versionName: String,
    val apkSize: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val isDebuggable: Boolean,
    val activitiesCount: Int,
    val servicesCount: Int,
    val receiversCount: Int,
    val sha256: String,
    val md5: String,
    val permissions: List<String>,
    val dangerScore: Int, // 0 - 100
    val riskLevel: String, // "SAFE", "MEDIUM", "HIGH"
    val issues: List<String>,
    val recommendations: List<String>
)

object ApkFileAnalyzer {

    suspend fun analyzeApk(context: Context, uri: Uri): ApkAnalysisResult = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val cursor = resolver.query(uri, null, null, null, null)
        var fileName = "unknown.apk"
        var fileSize = 0L
        
        cursor?.use {
            if (it.moveToFirst()) {
                val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                val sizeIndex = it.getColumnIndex(android.provider.OpenableColumns.SIZE)
                if (nameIndex != -1) fileName = it.getString(nameIndex)
                if (sizeIndex != -1) fileSize = it.getLong(sizeIndex)
            }
        }

        // Copy source Uri to a temp file so PackageManager can read the archive info
        val tempFile = File(context.cacheDir, "scan_temp_${System.currentTimeMillis()}.apk")
        resolver.openInputStream(uri)?.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        
        if (fileSize == 0L) {
            fileSize = tempFile.length()
        }

        val pm = context.packageManager
        
        @Suppress("DEPRECATION")
        val packageInfo = pm.getPackageArchiveInfo(
            tempFile.absolutePath,
            PackageManager.GET_PERMISSIONS or 
            PackageManager.GET_ACTIVITIES or 
            PackageManager.GET_SERVICES or 
            PackageManager.GET_RECEIVERS or 
            PackageManager.GET_SIGNATURES
        )

        if (packageInfo == null) {
            tempFile.delete()
            throw IllegalArgumentException("This file is not a valid APK package or is corrupted.")
        }

        val appInfo = packageInfo.applicationInfo ?: ApplicationInfo()
        appInfo.sourceDir = tempFile.absolutePath
        appInfo.publicSourceDir = tempFile.absolutePath

        val label = try {
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            "APK Package"
        }

        val versionName = packageInfo.versionName ?: "1.0"
        val packageName = packageInfo.packageName ?: "com.example.unknown"
        val targetSdk = appInfo.targetSdkVersion
        val minSdk = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            appInfo.minSdkVersion
        } else {
            21 // Default fallback for old versions
        }

        val isDebuggable = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val activitiesCount = packageInfo.activities?.size ?: 0
        val servicesCount = packageInfo.services?.size ?: 0
        val receiversCount = packageInfo.receivers?.size ?: 0

        // Parse signature hashes (MD5 & SHA256)
        var sha256 = "Unavailable"
        var md5 = "Unavailable"
        try {
            @Suppress("DEPRECATION")
            val signatures = packageInfo.signatures
            if (!signatures.isNullOrEmpty()) {
                val certBytes = signatures[0].toByteArray()
                
                val mdSha256 = MessageDigest.getInstance("SHA-256")
                val mdMd5 = MessageDigest.getInstance("MD5")
                
                val sha256Bytes = mdSha256.digest(certBytes)
                val md5Bytes = mdMd5.digest(certBytes)
                
                sha256 = sha256Bytes.joinToString(":") { "%02X".format(it) }
                md5 = md5Bytes.joinToString(":") { "%02X".format(it) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val permissions = packageInfo.requestedPermissions?.toList() ?: emptyList()

        // Risk Evaluation Logic
        val issues = mutableListOf<String>()
        val recommendations = mutableListOf<String>()
        var score = 0 // higher is more dangerous

        if (isDebuggable) {
            score += 25
            issues.add("Debuggable flag enabled (allows easy manipulation and reverse engineering)")
            recommendations.add("Disable debug mode in production builds.")
        }

        // Dangerous Permissions assessment
        val dangerousMap = mapOf(
            "android.permission.RECEIVE_SMS" to ("SMS interception risk" to "Do not grant SMS permission unless absolutely necessary."),
            "android.permission.SEND_SMS" to ("Allows sending premium SMS messages behind scene" to "Double-check developer authenticity before install."),
            "android.permission.RECORD_AUDIO" to ("Launches microphone tracking" to "Ensure app requires dynamic microphone usage."),
            "android.permission.CAMERA" to ("Unrestricted camera tracking capability" to "Verify the privacy settings."),
            "android.permission.ACCESS_FINE_LOCATION" to ("Real-time precise location tracking" to "Consider selecting coarse location instead."),
            "android.permission.BIND_ACCESSIBILITY_SERVICE" to ("Accessibility Services Abuse (can read and hijack UI/overlays)" to "Critical risk. DO NOT install or approve accessibility access if suspicious."),
            "android.permission.SYSTEM_ALERT_WINDOW" to ("Overlay Abuse (can draw fake screens over other apps)" to "Refuse overlay rendering permission under unknown contexts.")
        )

        dangerousMap.forEach { (perm, details) ->
            if (permissions.contains(perm)) {
                score += 15
                issues.add(details.first)
                recommendations.add(details.second)
            }
        }

        // General permission overload
        val dangerousCount = permissions.count { it in RiskAnalyzer.dangerousPermissions }
        if (dangerousCount > 5) {
            score += 10
            issues.add("High quantity ($dangerousCount) of dangerous permissions requested")
            recommendations.add("Review the full permission outline to ensure the requests align with functionality.")
        }

        // Exported components risk
        // If an app has many activities/receivers, some could be unprotected exported components
        if (activitiesCount > 0 && (packageInfo.activities?.count { it.exported } ?: 0) > 3) {
            score += 8
            issues.add("Multiple exported activities detected without security constraints")
            recommendations.add("Check app signature behavior prior to granting deep access.")
        }

        // Normalize score 0-100
        val finalDanger = score.coerceIn(0, 100)
        val riskLevel = when {
            finalDanger >= 60 -> "HIGH"
            finalDanger >= 25 -> "MEDIUM"
            else -> "SAFE"
        }

        if (issues.isEmpty()) {
            issues.add("No critical vulnerabilities detected")
            recommendations.add("App displays proper metadata alignment and safe configuration.")
        }

        // Clean up temp file
        tempFile.delete()

        ApkAnalysisResult(
            fileName = fileName,
            packageName = packageName,
            appLabel = label,
            versionName = versionName,
            apkSize = fileSize,
            minSdk = minSdk,
            targetSdk = targetSdk,
            isDebuggable = isDebuggable,
            activitiesCount = activitiesCount,
            servicesCount = servicesCount,
            receiversCount = receiversCount,
            sha256 = sha256,
            md5 = md5,
            permissions = permissions,
            dangerScore = finalDanger,
            riskLevel = riskLevel,
            issues = issues,
            recommendations = recommendations
        )
    }
}
