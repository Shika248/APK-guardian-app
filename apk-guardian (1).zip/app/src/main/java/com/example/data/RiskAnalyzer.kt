package com.example.data

object RiskAnalyzer {
    enum class RiskLevel { SAFE, LOW, MEDIUM, HIGH, CRITICAL }

    val dangerousPermissions = setOf(
        "android.permission.READ_CONTACTS",
        "android.permission.WRITE_CONTACTS",
        "android.permission.READ_CALENDAR",
        "android.permission.WRITE_CALENDAR",
        "android.permission.SEND_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_WAP_PUSH",
        "android.permission.RECEIVE_MMS",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.RECORD_AUDIO",
        "android.permission.CAMERA",
        "android.permission.READ_PHONE_STATE",
        "android.permission.READ_PHONE_NUMBERS",
        "android.permission.CALL_PHONE",
        "android.permission.ANSWER_PHONE_CALLS",
        "android.permission.ADD_VOICEMAIL",
        "android.permission.USE_SIP",
        "android.permission.PROCESS_OUTGOING_CALLS",
        "android.permission.READ_CALL_LOG",
        "android.permission.WRITE_CALL_LOG",
        "android.permission.BIND_DEVICE_ADMIN",
        "android.permission.BIND_ACCESSIBILITY_SERVICE",
        "android.permission.SYSTEM_ALERT_WINDOW"
    )

    fun getRisk(app: InstalledApp): RiskLevel {
        var score = 0
        
        // Installer checks
        val installer = app.installer
        val trustedStores = listOf("com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia", "com.xiaomi.mipicks")
        
        if (installer == null) {
            score += 3 // Unknown source / Sideloaded
        } else if (!trustedStores.contains(installer)) {
            score += 2 // Unrecognized store
        }
        
        // Permission checks
        val dangerousCount = app.requestedPermissions.count { it in dangerousPermissions }
        if (dangerousCount > 3) score += 1
        if (dangerousCount > 6) score += 2
        if (dangerousCount > 10) score += 3
        
        if (app.requestedPermissions.contains("android.permission.BIND_ACCESSIBILITY_SERVICE")) score += 3
        if (app.requestedPermissions.contains("android.permission.SYSTEM_ALERT_WINDOW")) score += 2
        if (app.requestedPermissions.contains("android.permission.RECEIVE_SMS")) score += 2
        if (app.requestedPermissions.contains("android.permission.READ_SMS")) score += 2
        
        return when {
            score >= 8 -> RiskLevel.CRITICAL
            score >= 6 -> RiskLevel.HIGH
            score >= 4 -> RiskLevel.MEDIUM
            score >= 2 -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }
    }
}
