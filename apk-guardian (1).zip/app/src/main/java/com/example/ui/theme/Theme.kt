package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val CyberColorScheme = darkColorScheme(
    primary = NeonGreen,
    secondary = SafeGreen,
    tertiary = WarningYellow,
    background = CyberBlack,
    surface = CyberDark,
    surfaceVariant = SurfaceVariantDark,
    onPrimary = CyberBlack,
    onSecondary = CyberBlack,
    onTertiary = CyberBlack,
    onBackground = TextWhite,
    onSurface = TextWhite,
    onSurfaceVariant = TextWhite,
    error = DangerRed,
    onError = PureWhite,
    outline = OutlineColor
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Dynamic color is available on Android 12+
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
  val colorScheme = CyberColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
