package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.DashboardMetrics
import com.example.ui.theme.*

@Composable
fun DashboardScreen(metrics: DashboardMetrics, isScanning: Boolean, onScanClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        
        // App Bar Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SafeGreen.copy(alpha = 0.1f))
                        .border(1.dp, SafeGreen.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Security, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("APK Guardian", style = MaterialTheme.typography.titleMedium, color = PureWhite, fontWeight = FontWeight.Bold)
                    Text("SYSTEM PROTECTED", style = MaterialTheme.typography.labelSmall, color = SafeGreen, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(24.dp))

        // Big Ring Chart with Score
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(32.dp))
                .background(Brush.verticalGradient(listOf(CyberDark.copy(alpha = 0.5f), Color.Transparent)))
                .border(1.dp, OutlineColor, RoundedCornerShape(32.dp))
                .padding(vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(160.dp)
            ) {
                val total = metrics.totalApps.toFloat().coerceAtLeast(1f)
                val safeSweep = (metrics.safeApps / total) * 360f
                val warningSweep = ((metrics.lowRiskApps + metrics.mediumRiskApps) / total) * 360f
                val dangerSweep = ((metrics.highRiskApps + metrics.criticalRiskApps) / total) * 360f
                
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 12.dp.toPx()
                    
                    // Background Track
                    drawArc(
                        color = CyberDark,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                    
                    if (!isScanning && metrics.totalApps > 0) {
                        var startAngle = -90f
                        
                        // Safe Green
                        if (safeSweep > 0) {
                            drawArc(
                                color = SafeGreen,
                                startAngle = startAngle,
                                sweepAngle = safeSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            startAngle += safeSweep
                        }
                        
                        // Warning Orange/Yellow
                        if (warningSweep > 0) {
                            drawArc(
                                color = WarningYellow,
                                startAngle = startAngle,
                                sweepAngle = warningSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                            startAngle += warningSweep
                        }
                        
                        // Danger Red
                        if (dangerSweep > 0) {
                            drawArc(
                                color = DangerRed,
                                startAngle = startAngle,
                                sweepAngle = dangerSweep,
                                useCenter = false,
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }
                    }
                }
                
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (isScanning) {
                        CircularProgressIndicator(color = SafeGreen)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Scanning...", color = TextGray, fontSize = 12.sp)
                    } else {
                        val safePercent = if (metrics.totalApps > 0) ((metrics.safeApps.toFloat() / metrics.totalApps) * 100).toInt() else 0
                        Text(
                            text = "$safePercent",
                            style = MaterialTheme.typography.displayLarge.copy(fontWeight = FontWeight.Light, color = PureWhite)
                        )
                        Text("Trust Score", color = TextGray, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Surface(
            color = SafeGreen.copy(alpha = 0.1f),
            shape = RoundedCornerShape(100.dp),
            border = BorderStroke(1.dp, SafeGreen.copy(alpha = 0.3f))
        ) {
            Text(
                "Device Status: Optimal",
                color = SafeGreen,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                fontWeight = FontWeight.SemiBold
            )
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = onScanClick,
            enabled = !isScanning,
            colors = ButtonDefaults.buttonColors(containerColor = PureWhite, contentColor = CyberBlack, disabledContainerColor = CyberDark, disabledContentColor = TextGray),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Filled.Security, contentDescription = "Scan")
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isScanning) "Scanning..." else "Scan New APK", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Metrics Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                MetricCard("Total Apps", metrics.totalApps.toString(), Icons.Filled.Check, SafeGreen)
            }
            item {
                MetricCard("Unknown Source", metrics.unknownSourceApps.toString(), Icons.Filled.Warning, WarningYellow)
            }
            item {
                val highR = metrics.highRiskApps + metrics.criticalRiskApps
                MetricCard("High Risk", highR.toString(), Icons.Filled.Error, DangerRed)
            }
            item {
                val medR = metrics.lowRiskApps + metrics.mediumRiskApps
                MetricCard("Suspicious", medR.toString(), Icons.Filled.Warning, SuspiciousOrange)
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, iconColor: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, OutlineColor),
        modifier = Modifier.fillMaxWidth().height(100.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = title, color = TextGray, style = MaterialTheme.typography.labelMedium)
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = value,
                    color = PureWhite,
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Box(
                    modifier = Modifier.fillMaxWidth().height(4.dp).padding(start = 16.dp, bottom = 4.dp).clip(RoundedCornerShape(100.dp)).background(CyberBlack),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.15f).background(iconColor))
                }
            }
        }
    }
}
