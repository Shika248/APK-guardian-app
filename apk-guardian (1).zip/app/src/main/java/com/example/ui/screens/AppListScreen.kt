package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.InstalledApp
import com.example.data.RiskAnalyzer
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppListScreen(
    apps: List<Pair<InstalledApp, RiskAnalyzer.RiskLevel>>,
    onAppClick: (InstalledApp) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    
    val filteredApps = remember(searchQuery, apps) {
        if (searchQuery.isEmpty()) apps
        else apps.filter { it.first.name.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search installed apps...", color = TextGray) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search", tint = TextGray) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = OutlineColor,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = CyberDark,
                unfocusedContainerColor = CyberDark
            ),
            shape = RoundedCornerShape(16.dp)
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredApps, key = { it.first.packageName }) { (app, risk) ->
                AppListItem(app = app, risk = risk, onClick = { onAppClick(app) })
            }
        }
    }
}

@Composable
fun AppListItem(app: InstalledApp, risk: RiskAnalyzer.RiskLevel, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, OutlineColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Icon
            val bitmap = remember(app.icon) { app.icon?.toBitmap()?.asImageBitmap() }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = app.name,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp))
                )
            } else {
                Box(
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceVariantDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Android, contentDescription = null, tint = TextGray)
                }
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            // Text
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, style = MaterialTheme.typography.titleMedium, color = TextWhite, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = TextGray, maxLines = 1)
            }
            
            Spacer(modifier = Modifier.width(8.dp))
            
            // Risk Badge
            val (riskColor, riskText) = when(risk) {
                RiskAnalyzer.RiskLevel.SAFE -> SafeGreen to "SAFE"
                RiskAnalyzer.RiskLevel.LOW -> SafeGreen to "LOW"
                RiskAnalyzer.RiskLevel.MEDIUM -> WarningYellow to "MED"
                RiskAnalyzer.RiskLevel.HIGH -> SuspiciousOrange to "HIGH"
                RiskAnalyzer.RiskLevel.CRITICAL -> DangerRed to "CRIT"
            }
            
            Surface(
                color = riskColor.copy(alpha = 0.2f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = riskText,
                    color = riskColor,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    fontWeight = FontWeight.Bold
                )
            }
            
            Icon(Icons.Filled.ChevronRight, contentDescription = "View Details", tint = TextGray)
        }
    }
}
