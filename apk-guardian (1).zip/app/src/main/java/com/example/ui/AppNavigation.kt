package com.example.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.InstalledApp
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.serialization.Serializable
import androidx.compose.ui.platform.LocalContext

sealed class Screen(val route: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Dashboard : Screen("dashboard", "Dashboard", Icons.Filled.Dashboard)
    object Apps : Screen("apps", "Apps", Icons.Filled.Apps)
    object Scanner : Screen("scanner", "Scanner", Icons.Filled.DocumentScanner)
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    val context = LocalContext.current
    
    val metrics by viewModel.dashboardMetrics.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val apps by viewModel.installedApps.collectAsState()
    val aiAnalysis by viewModel.aiAnalysis.collectAsState()

    var selectedApp by remember { mutableStateOf<InstalledApp?>(null) }
    
    val items = listOf(
        Screen.Dashboard,
        Screen.Apps,
        Screen.Scanner
    )

    Scaffold(
        bottomBar = {
            if (selectedApp == null) {
                Surface(
                    color = SurfaceVariantDark,
                    tonalElevation = 0.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, OutlineColor)
                ) {
                    NavigationBar(
                        containerColor = Color.Transparent,
                        contentColor = TextDarkGray,
                        tonalElevation = 0.dp
                    ) {
                        val navBackStackEntry by navController.currentBackStackEntryAsState()
                        val currentRoute = navBackStackEntry?.destination?.route
                        
                        items.forEach { screen ->
                            NavigationBarItem(
                                icon = { Icon(screen.icon, contentDescription = screen.title) },
                                label = { Text(screen.title, fontSize = 10.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium) },
                                selected = currentRoute == screen.route,
                                onClick = {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = NeonGreen,
                                    selectedTextColor = NeonGreen,
                                    unselectedIconColor = TextDarkGray,
                                    unselectedTextColor = TextDarkGray,
                                    indicatorColor = Color.Transparent
                                )
                            )
                        }
                    }
                }
            }
        },
        containerColor = CyberBlack
    ) { padding ->
        if (selectedApp != null) {
            val risk = apps.find { it.first.packageName == selectedApp!!.packageName }?.second ?: com.example.data.RiskAnalyzer.RiskLevel.SAFE
            AppDetailScreen(
                app = selectedApp!!,
                riskLevel = risk,
                aiAnalysis = aiAnalysis[selectedApp!!.packageName],
                onAnalyzeClick = { viewModel.analyzeAppWithGemini(selectedApp!!) },
                onBack = { selectedApp = null }
            )
        } else {
            NavHost(
                navController = navController,
                startDestination = Screen.Dashboard.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(Screen.Dashboard.route) {
                    DashboardScreen(
                        metrics = metrics,
                        isScanning = isScanning,
                        onScanClick = { viewModel.scanApps(context) }
                    )
                }
                composable(Screen.Apps.route) {
                    AppListScreen(
                        apps = apps,
                        onAppClick = { selectedApp = it }
                    )
                }
                composable(Screen.Scanner.route) { ApkScannerScreen() }
            }
        }
    }
}
