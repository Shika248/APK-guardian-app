package com.example.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppScanner
import com.example.data.GeminiSecurityAgent
import com.example.data.InstalledApp
import com.example.data.RiskAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardMetrics(
    val totalApps: Int = 0,
    val safeApps: Int = 0,
    val lowRiskApps: Int = 0,
    val mediumRiskApps: Int = 0,
    val highRiskApps: Int = 0,
    val criticalRiskApps: Int = 0,
    val unknownSourceApps: Int = 0
)

class MainViewModel : ViewModel() {
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _installedApps = MutableStateFlow<List<Pair<InstalledApp, RiskAnalyzer.RiskLevel>>>(emptyList())
    val installedApps: StateFlow<List<Pair<InstalledApp, RiskAnalyzer.RiskLevel>>> = _installedApps.asStateFlow()

    private val _dashboardMetrics = MutableStateFlow(DashboardMetrics())
    val dashboardMetrics: StateFlow<DashboardMetrics> = _dashboardMetrics.asStateFlow()

    private val geminiAgent = GeminiSecurityAgent()
    
    private val _aiAnalysis = MutableStateFlow<Map<String, String>>(emptyMap())
    val aiAnalysis: StateFlow<Map<String, String>> = _aiAnalysis.asStateFlow()

    fun scanApps(context: Context, includeSystem: Boolean = false) {
        viewModelScope.launch {
            _isScanning.value = true
            val scanner = AppScanner(context)
            val apps = scanner.getInstalledApps(includeSystem)
            
            val appsWithRisk = apps.map { app ->
                app to RiskAnalyzer.getRisk(app)
            }
            
            _installedApps.value = appsWithRisk
            
            var safe = 0
            var low = 0
            var med = 0
            var high = 0
            var crit = 0
            var unknown = 0
            
            appsWithRisk.forEach { (app, risk) ->
                when(risk) {
                    RiskAnalyzer.RiskLevel.SAFE -> safe++
                    RiskAnalyzer.RiskLevel.LOW -> low++
                    RiskAnalyzer.RiskLevel.MEDIUM -> med++
                    RiskAnalyzer.RiskLevel.HIGH -> high++
                    RiskAnalyzer.RiskLevel.CRITICAL -> crit++
                }
                if (app.installer == null) unknown++
            }
            
            _dashboardMetrics.value = DashboardMetrics(
                totalApps = apps.size,
                safeApps = safe,
                lowRiskApps = low,
                mediumRiskApps = med,
                highRiskApps = high,
                criticalRiskApps = crit,
                unknownSourceApps = unknown
            )
            
            _isScanning.value = false
        }
    }

    fun analyzeAppWithGemini(app: InstalledApp) {
        if (_aiAnalysis.value.containsKey(app.packageName)) return
        
        viewModelScope.launch {
            _aiAnalysis.value = _aiAnalysis.value + (app.packageName to "Analyzing...")
            val result = geminiAgent.analyzeApp(app)
            _aiAnalysis.value = _aiAnalysis.value + (app.packageName to result)
        }
    }
}
