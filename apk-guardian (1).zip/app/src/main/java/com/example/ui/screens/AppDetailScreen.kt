package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.data.InstalledApp
import com.example.data.RiskAnalyzer
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    app: InstalledApp,
    riskLevel: RiskAnalyzer.RiskLevel,
    aiAnalysis: String?,
    onAnalyzeClick: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberBlack,
                    titleContentColor = TextWhite,
                    navigationIconContentColor = TextWhite
                )
            )
        },
        containerColor = CyberBlack
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                AppHeader(app, riskLevel)
            }
            
            item {
                AiAnalysisSection(aiAnalysis, onAnalyzeClick)
            }
            
            item {
                AppDetailsSection(app)
            }
            
            item {
                val context = androidx.compose.ui.platform.LocalContext.current
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
                            if (launchIntent != null) {
                                context.startActivity(launchIntent)
                            } else {
                                android.widget.Toast.makeText(context, "App cannot be launched", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = CyberBlack),
                        modifier = Modifier.weight(1f).height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Filled.Launch, contentDescription = "Launch")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Launch", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Button(
                        onClick = {
                            val intent = android.content.Intent(android.content.Intent.ACTION_DELETE)
                            intent.data = android.net.Uri.parse("package:${app.packageName}")
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed, contentColor = PureWhite),
                        modifier = Modifier.weight(1f).height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Filled.Delete, contentDescription = "Uninstall")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Uninstall", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Requested Permissions", style = MaterialTheme.typography.titleMedium, color = TextWhite, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            val dangerous = app.requestedPermissions.filter { it in RiskAnalyzer.dangerousPermissions }.sorted()
            val safe = app.requestedPermissions.filter { it !in RiskAnalyzer.dangerousPermissions }.sorted()
            
            items(dangerous) { perm ->
                PermissionItem(permission = perm, isDangerous = true)
            }
            
            items(safe) { perm ->
                PermissionItem(permission = perm, isDangerous = false)
            }
        }
    }
}

@Composable
fun AppHeader(app: InstalledApp, risk: RiskAnalyzer.RiskLevel) {
    val bitmap = remember(app.icon) { app.icon?.toBitmap()?.asImageBitmap() }
    
    val (riskColor, riskText) = when(risk) {
        RiskAnalyzer.RiskLevel.SAFE -> SafeGreen to "Safe"
        RiskAnalyzer.RiskLevel.LOW -> SafeGreen to "Low Risk"
        RiskAnalyzer.RiskLevel.MEDIUM -> WarningYellow to "Medium Risk"
        RiskAnalyzer.RiskLevel.HIGH -> SuspiciousOrange to "High Risk"
        RiskAnalyzer.RiskLevel.CRITICAL -> DangerRed to "Critical Risk"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, OutlineColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = null,
                    modifier = Modifier.size(80.dp).clip(RoundedCornerShape(16.dp))
                )
            } else {
                Box(
                    modifier = Modifier.size(80.dp).clip(RoundedCornerShape(16.dp)).background(SurfaceVariantDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Android, contentDescription = null, tint = TextGray, modifier = Modifier.size(40.dp))
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            Text(app.name, style = MaterialTheme.typography.headlineSmall, color = TextWhite, fontWeight = FontWeight.Bold)
            Text(app.packageName, style = MaterialTheme.typography.bodyMedium, color = TextGray)
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Surface(
                color = riskColor.copy(alpha = 0.15f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (risk == RiskAnalyzer.RiskLevel.SAFE) Icons.Filled.CheckCircle else Icons.Filled.Warning, contentDescription = null, tint = riskColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(riskText.uppercase(), color = riskColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun AiAnalysisSection(aiAnalysis: String?, onAnalyzeClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, OutlineColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SmartToy, contentDescription = null, tint = NeonGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI Security Analyst", style = MaterialTheme.typography.titleMedium, color = TextWhite, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            
            if (aiAnalysis == null) {
                Button(
                    onClick = onAnalyzeClick,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariantDark, contentColor = TextWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Analyze with Gemini API")
                }
            } else {
                Text(
                    text = aiAnalysis,
                    color = if (aiAnalysis == "Analyzing...") TextGray else TextWhite,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 22.sp
                )
                if (aiAnalysis == "Analyzing...") {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(color = NeonGreen, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun AppDetailsSection(app: InstalledApp) {
    val installerName = when (app.installer) {
        "com.android.vending" -> "Google Play Store"
        "com.sec.android.app.samsungapps" -> "Samsung Galaxy Store"
        "com.amazon.venezia" -> "Amazon Appstore"
        null -> "Unknown Source (Sideloaded)"
        else -> app.installer
    }
    val installerColor = if (app.installer == null) SuspiciousOrange else SafeGreen

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberDark),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, OutlineColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            DetailRow("Version", app.version)
            DetailRow("App Size", "${app.apkSize / (1024 * 1024)} MB")
            DetailRow("Source", installerName, installerColor)
            DetailRow("Type", if (app.isSystemApp) "System App" else "User App")
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, valueColor: Color = TextWhite) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TextGray, style = MaterialTheme.typography.bodyMedium)
        Text(value, color = valueColor, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PermissionItem(permission: String, isDangerous: Boolean) {
    val name = permission.substringAfterLast(".")
    
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            if (isDangerous) Icons.Filled.Warning else Icons.Filled.Check,
            contentDescription = null,
            tint = if (isDangerous) DangerRed else TextGray,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = name,
            color = if (isDangerous) TextWhite else TextGray,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isDangerous) FontWeight.Bold else FontWeight.Normal
        )
    }
}
