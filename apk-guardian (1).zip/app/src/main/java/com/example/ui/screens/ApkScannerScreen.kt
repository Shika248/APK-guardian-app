package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ApkAnalysisResult
import com.example.data.ApkFileAnalyzer
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ApkScannerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    
    var isAnalyzing by remember { mutableStateOf(false) }
    var analysisResult by remember { mutableStateOf<ApkAnalysisResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var scannedUri by remember { mutableStateOf<Uri?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scannedUri = uri
            isAnalyzing = true
            errorMessage = null
            analysisResult = null
            scope.launch {
                try {
                    val result = ApkFileAnalyzer.analyzeApk(context, uri)
                    analysisResult = result
                } catch (e: Exception) {
                    errorMessage = e.message ?: "Failed to read or parse the selected APK file."
                } finally {
                    isAnalyzing = false
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "APK Security Scanner",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = PureWhite
                )
            )
            Text(
                "Select and scan sideloaded packages securely before installing them.",
                style = MaterialTheme.typography.bodyMedium.copy(color = TextGray)
            )
        }

        item {
            // Drag & Drop / Upload Area
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { filePickerLauncher.launch("application/vnd.android.package-archive") },
                colors = CardDefaults.cardColors(containerColor = CyberDark),
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, if (isAnalyzing) SafeGreen else OutlineColor)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(color = SafeGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Analyzing APK Package...",
                            color = SafeGreen,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Parsing manifest structure and compiling signature metrics...",
                            color = TextGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    } else {
                        Icon(
                            Icons.Filled.CloudUpload,
                            contentDescription = "Upload",
                            tint = SafeGreen,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "CHOOSE OR DROPA FILE",
                            color = PureWhite,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            "Supports any standard Android package (.apk file)",
                            color = TextGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { filePickerLauncher.launch("application/vnd.android.package-archive") },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceVariantDark, contentColor = PureWhite),
                            border = BorderStroke(1.dp, OutlineColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Browse Device Storage", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Error message if any
        if (errorMessage != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DangerRed.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, DangerRed.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Error, tint = DangerRed, contentDescription = "Error")
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(errorMessage!!, color = PureWhite, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        // Analysis Results Card
        val result = analysisResult
        if (result != null) {
            item {
                Text(
                    "Scan Results",
                    style = MaterialTheme.typography.titleMedium,
                    color = PureWhite,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            item {
                // Main Metric Card (Score Circle)
                val (riskColor, riskTitle) = when (result.riskLevel) {
                    "SAFE" -> SafeGreen to "Safe"
                    "MEDIUM" -> WarningYellow to "Medium Risk"
                    else -> DangerRed to "High Risk"
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OutlineColor)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(130.dp)
                        ) {
                            val scorePercentage = result.dangerScore.toFloat() / 100f
                            val sweepAngle = scorePercentage * 360f
                            
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val strokeWidth = 10.dp.toPx()
                                // Gray Background track
                                drawArc(
                                    color = CyberBlack,
                                    startAngle = 0f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                )
                                // Active Risk Sweep
                                drawArc(
                                    color = riskColor,
                                    startAngle = -90f,
                                    sweepAngle = sweepAngle.coerceAtLeast(4f),
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                                )
                            }

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${100 - result.dangerScore}",
                                    style = MaterialTheme.typography.displaySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = PureWhite
                                    )
                                )
                                Text(
                                    text = "Security Score",
                                    color = TextGray,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            color = riskColor.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(100.dp),
                            border = BorderStroke(1.dp, riskColor.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = "Risk Level: $riskTitle".uppercase(),
                                color = riskColor,
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // General APK stats Grid
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OutlineColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Info, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Package Information", style = MaterialTheme.typography.titleSmall, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = OutlineColor)
                        InfoRow("App Label", result.appLabel)
                        InfoRow("Package", result.packageName)
                        InfoRow("Version", result.versionName)
                        InfoRow("File Size", "%.2f MB".format(result.apkSize.toFloat() / (1024f * 1024f)))
                        InfoRow("Min SDK", result.minSdk.toString())
                        InfoRow("Target SDK", result.targetSdk.toString())
                        InfoRow("Debuggable Flag", if (result.isDebuggable) "Enabled (Vulnerable)" else "Disabled (Safe)", if (result.isDebuggable) DangerRed else SafeGreen)
                        InfoRow("Component Count", "${result.activitiesCount} Activities • ${result.servicesCount} Services • ${result.receiversCount} Receivers")
                    }
                }
            }

            // Safety Analysis Findings Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OutlineColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.FactCheck, contentDescription = null, tint = WarningYellow, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Security Findings", style = MaterialTheme.typography.titleSmall, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = OutlineColor)
                        result.issues.forEach { issue ->
                            Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(vertical = 2.dp)) {
                                Text("•", color = WarningYellow, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(issue, color = TextWhite, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            // Recommendations Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OutlineColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Recommend, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Recommendations", style = MaterialTheme.typography.titleSmall, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = OutlineColor)
                        result.recommendations.forEach { recommendation ->
                            Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(vertical = 2.dp)) {
                                Icon(Icons.Filled.Check, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(16.dp).padding(top = 2.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(recommendation, color = TextGray, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            // Raw Certificate Fingerprint
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = CyberDark),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, OutlineColor)
                ) {
                    Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Badge, contentDescription = null, tint = SafeGreen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Signing Certificate Hash", style = MaterialTheme.typography.titleSmall, color = PureWhite, fontWeight = FontWeight.Bold)
                        }
                        Divider(color = OutlineColor)
                        Text("SHA-256 Fingerprint", style = MaterialTheme.typography.labelSmall, color = TextGray)
                        Text(
                            result.sha256,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = TextWhite,
                            modifier = Modifier
                                .background(CyberBlack, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                                .fillMaxWidth()
                        )
                        Text("MD5 Fingerprint", style = MaterialTheme.typography.labelSmall, color = TextGray)
                        Text(
                            result.md5,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = TextWhite,
                            modifier = Modifier
                                .background(CyberBlack, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                                .fillMaxWidth()
                        )
                    }
                }
            }

            // Requested Permissions list
            if (result.permissions.isNotEmpty()) {
                item {
                    Text(
                        "Permissions Profile (${result.permissions.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                items(result.permissions) { permission ->
                    val isDangerous = permission in com.example.data.RiskAnalyzer.dangerousPermissions
                    val pName = permission.substringAfterLast(".")
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = CyberDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, OutlineColor)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (isDangerous) Icons.Filled.Warning else Icons.Filled.VerifiedUser,
                                contentDescription = null,
                                tint = if (isDangerous) DangerRed else TextGray,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                pName,
                                color = if (isDangerous) PureWhite else TextWhite,
                                fontWeight = if (isDangerous) FontWeight.Bold else FontWeight.Normal,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            if (scannedUri != null) {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            try {
                                val installIntent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                    setDataAndType(scannedUri, "application/vnd.android.package-archive")
                                    flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                                }
                                context.startActivity(installIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Could not launch installer.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SafeGreen, contentColor = CyberBlack),
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(Icons.Filled.SystemUpdate, contentDescription = "Install")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Install Checked APK", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = TextWhite) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextGray, style = MaterialTheme.typography.bodyMedium)
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            value,
            color = valueColor,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}
