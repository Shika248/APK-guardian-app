package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF0A0B0D)
val CyberDark = Color(0xFF16181D)
val SurfaceVariantDark = Color(0xFF111318)
val NeonGreen = Color(0xFF10B981)
val SafeGreen = Color(0xFF34D399)
val WarningYellow = Color(0xFFF59E0B)
val SuspiciousOrange = Color(0xFFF97316)
val DangerRed = Color(0xFFEF4444)
val TextGray = Color(0xFF94A3B8)
val TextDarkGray = Color(0xFF64748B)
val TextWhite = Color(0xFFE2E8F0)
val PureWhite = Color(0xFFFFFFFF)
val OutlineColor = Color(0x0DFFFFFF) // White 5%
